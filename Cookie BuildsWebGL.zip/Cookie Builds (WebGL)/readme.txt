Cookie Crusade (2020)
A Game by Michael Hosp, Thomas Nordrum, Haley Peterson, and Joey Rongstad

Cookie Crusade is a game where the player, a team of three cookies, must search through
a randomly generated level with connected rooms. The player is searching for the T-Rex that
has been captured by the evil Broccoli soldiers. The player must use each of the three cookie
team members to battle their way through the map and reach the T-Rex without being defeated.

The controls are simple:
W A S D - control movement
Q and E - switch left and right between the cookie team members
Left Mouse Click - attack with the current cookie's special attack

To Install the game:

(PC Version) Run the .exe file from the build folder
(WebGL Version) After building, run the index.html file in a browser that supports WebGL


